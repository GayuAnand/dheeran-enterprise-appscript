export const EN_MAPPING = {
  COMMON: {
    ABOUT: 'About',
    CABLE: 'Cable',
    DASHBOARD: 'Dashboard',
    HOME: 'Home',
    LOGOUT: 'Logout',
    SEARCH: 'Search',
    SIGNIN: 'Sign in',
    TASKS: 'Tasks',
    VERSION: 'Version',
  },
};
